package com.example.timer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.format.DateUtils;
import android.view.InputDevice;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public TextView time;
    public int tt;
    EditText text_input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
10

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        time = findViewById(R.id.timer_text);
        text_input = (EditText) findViewById(R.id.timer_input);

    }
    public void pizza_button(View view) {
        tt = Integer.parseInt(text_input.getText().toString());
        /*Intent intent = new Intent(this, Pizza_Activity.class);
        startActivity(intent);*/

        new CountDownTimer(tt*1000, 1000) {
            @Override
            public void onTick(long l) {
                time.setText(DateUtils.formatElapsedTime(l / 1000));
            }

            @Override
            public void onFinish() {
                time.setText("-");
                /*NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(Pizza_Activity.this, CHANNEL_ID)
                                .setContentTitle("Напоминание")
                                .setContentText("Пицца готова")
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "name", NotificationManager.IMPORTANCE_HIGH);
                }
                NotificationManagerCompat notificationManager =
                        NotificationManagerCompat.from(Pizza_Activity.this);
                notificationManager.notify(NOTIFY_ID, builder.build());*/

            }
        }.start();
    }

    public void pelmen_button(View view) {
        Intent intent2 = new Intent(this, Pelmen_Activity.class);
        startActivity(intent2);
    }

}